import 'package:flutter_test/flutter_test.dart';
import 'package:ds_catalog/app.dart';

void main() {
  testWidgets('shows all Design System categories', (tester) async {
    await tester.pumpWidget(const DsCatalogApp());
    expect(find.text('Component catalog'), findsOneWidget);
    expect(find.text('Inputs & Filters'), findsOneWidget);
    expect(find.text('Cart & Commerce'), findsOneWidget);
  });
}

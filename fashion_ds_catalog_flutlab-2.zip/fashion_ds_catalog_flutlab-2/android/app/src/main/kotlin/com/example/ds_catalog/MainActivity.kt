package com.example.ds_catalog

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()

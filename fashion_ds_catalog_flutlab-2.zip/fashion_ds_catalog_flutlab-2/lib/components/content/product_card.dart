import 'package:flutter/material.dart';
import '../../common/theme/app_colors.dart';

class ProductCard extends StatelessWidget {
  const ProductCard({super.key, this.compact = false});
  final bool compact;
  @override
  Widget build(BuildContext context) => SizedBox(
        width: 180,
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Container(
            height: compact ? 180 : 230,
            decoration: BoxDecoration(
              gradient: const LinearGradient(colors: [Color(0xFFFFB5C4), Color(0xFFFFE3E9)]),
              borderRadius: BorderRadius.circular(18),
            ),
            child: const Center(child: Icon(Icons.checkroom, size: 72, color: Colors.white)),
          ),
          const SizedBox(height: 10),
          const Text('Modern style outfit', style: TextStyle(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          const Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [Text('R\$ 239,90'), Icon(Icons.shopping_bag_outlined, size: 18, color: AppColors.textSecondary)]),
        ]),
      );
}

import 'package:flutter/material.dart';
import '../../common/theme/app_colors.dart';

class DsTabBar extends StatefulWidget {
  const DsTabBar({super.key});

  @override
  State<DsTabBar> createState() => _DsTabBarState();
}

class _DsTabBarState extends State<DsTabBar> {
  int selected = 0;
  static const icons = [Icons.home_rounded, Icons.style_rounded, Icons.grid_view_rounded, Icons.support_agent_rounded, Icons.person_rounded];

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        decoration: BoxDecoration(color: AppColors.primary, borderRadius: BorderRadius.circular(18)),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          for (var i = 0; i < icons.length; i++)
            IconButton(
              onPressed: () => setState(() => selected = i),
              icon: Icon(icons[i]),
              color: Colors.white.withValues(alpha: selected == i ? 1 : .55),
              style: selected == i ? IconButton.styleFrom(backgroundColor: Colors.white.withValues(alpha: .18)) : null,
            ),
        ]),
      );
}

class CategoryTabs extends StatefulWidget {
  const CategoryTabs({super.key});
  @override
  State<CategoryTabs> createState() => _CategoryTabsState();
}

class _CategoryTabsState extends State<CategoryTabs> {
  int selected = 0;
  final labels = const ['All', 'Man', 'Woman', 'Shirts', 'Pants'];
  @override
  Widget build(BuildContext context) => Wrap(spacing: 8, children: [
        for (var i = 0; i < labels.length; i++)
          ChoiceChip(label: Text(labels[i]), selected: selected == i, onSelected: (_) => setState(() => selected = i)),
      ]);
}

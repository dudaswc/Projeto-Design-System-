import '../../common/models/component_state.dart';
import 'action_button.dart';
import 'action_button_view_model.dart';

abstract final class ActionButtonFactory {
  static DsActionButton compact(ComponentState state) => DsActionButton(
        viewModel: ActionButtonViewModel(label: 'Buy now', state: state, size: ActionButtonSize.compact),
      );

  static DsActionButton fullWidth(ComponentState state) => DsActionButton(
        viewModel: ActionButtonViewModel(label: 'Proceed to checkout', state: state, size: ActionButtonSize.fullWidth),
      );
}

import '../../common/models/component_state.dart';

enum ActionButtonSize { compact, fullWidth }

class ActionButtonViewModel {
  const ActionButtonViewModel({required this.label, required this.state, required this.size});
  final String label;
  final ComponentState state;
  final ActionButtonSize size;
  bool get isDisabled => state == ComponentState.disabled;
}

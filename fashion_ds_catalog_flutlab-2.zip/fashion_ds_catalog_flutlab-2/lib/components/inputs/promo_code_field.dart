import 'package:flutter/material.dart';
import '../../common/theme/app_colors.dart';

class PromoCodeField extends StatelessWidget {
  const PromoCodeField({super.key, this.enabled = true});
  final bool enabled;

  @override
  Widget build(BuildContext context) => TextField(
        enabled: enabled,
        decoration: InputDecoration(
          hintText: 'PROMO CODE',
          filled: true,
          fillColor: enabled ? Colors.white : AppColors.disabled,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          suffixIcon: Padding(
            padding: const EdgeInsets.all(4),
            child: FilledButton(onPressed: enabled ? () {} : null, child: const Text('Apply')),
          ),
        ),
      );
}

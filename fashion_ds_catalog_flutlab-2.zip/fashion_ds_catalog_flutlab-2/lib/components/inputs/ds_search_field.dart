import 'package:flutter/material.dart';
import '../../common/models/component_state.dart';
import '../../common/theme/app_colors.dart';

class DsSearchField extends StatelessWidget {
  const DsSearchField({super.key, required this.state});
  final ComponentState state;

  @override
  Widget build(BuildContext context) => TextField(
        enabled: state != ComponentState.disabled,
        controller: state == ComponentState.filled ? TextEditingController(text: 'Dress') : null,
        decoration: InputDecoration(
          hintText: 'Search',
          prefixIcon: const Icon(Icons.search),
          suffixIcon: const Icon(Icons.tune),
          filled: true,
          fillColor: state == ComponentState.disabled ? AppColors.disabled : Colors.white,
          enabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.border)),
          focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: const BorderSide(color: AppColors.accent, width: 2)),
          disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
        autofocus: state == ComponentState.focused,
      );
}

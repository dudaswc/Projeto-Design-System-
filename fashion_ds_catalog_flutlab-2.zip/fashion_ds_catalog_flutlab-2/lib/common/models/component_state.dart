enum ComponentState { defaultState, focused, filled, pressed, selected, unselected, disabled }

extension ComponentStateLabel on ComponentState {
  String get label => switch (this) {
        ComponentState.defaultState => 'Default',
        ComponentState.focused => 'Focused',
        ComponentState.filled => 'Filled',
        ComponentState.pressed => 'Pressed',
        ComponentState.selected => 'Selected',
        ComponentState.unselected => 'Unselected',
        ComponentState.disabled => 'Disabled',
      };
}

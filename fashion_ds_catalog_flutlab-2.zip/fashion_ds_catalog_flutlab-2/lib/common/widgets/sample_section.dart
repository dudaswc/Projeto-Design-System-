import 'package:flutter/material.dart';
import '../theme/app_colors.dart';

class SampleSection extends StatelessWidget {
  const SampleSection({super.key, required this.title, required this.description, required this.child});

  final String title;
  final String description;
  final Widget child;

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(
          color: AppColors.surface,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.border),
        ),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text(title, style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 4),
          Text(description, style: const TextStyle(color: AppColors.textSecondary)),
          const SizedBox(height: 20),
          child,
        ]),
      );
}
